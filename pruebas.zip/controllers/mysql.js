var mysql = require('mysql');

 

exports.runQuery = function(Query,data,callback){


      var dbConfig = {
          host:'localhost',
          user:'root',
          password:'',
          database:'Chemixer'
      };

      var connection = mysql.createConnection(dbConfig);
      //console.log(Query);
      connection.connect(function(err) {
                if (err) throw console.log(err);
       console.log("conectado");
      });
   

        connection.query(Query,data, function(error, result){
            if (error) {
              throw console.log(error);
              callback(error,result);
            

            }
              else{
               // console.log(result);
                    callback(error,result);
              }

            
    });

connection.end();
}





