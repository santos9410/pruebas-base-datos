
/*
 * GET home page.
 */
var mysql = require('mysql');
var BD = require('../controllers/mysql.js');


exports.buscarUsuario=function(req,res){

 res.render('usuarios/administrarUsuarios', { title: 'buscar usuarios' })

}

exports.consultarUsuarios=function(req,res){
  var buscar=req.body.buscarid;
var Stringquery="SELECT * FROM usuarios where idUser=?";
                
                  BD.runQuery(Stringquery,buscar,function(error,data){
                  if(data.length>0){
                        console.log(data);
                   // res.render('usuarios/consultas',{title:'usuario consultado'});
                  }else{
                    console.log("no registrado");
                  }
        });


  
}

exports.editarUsuario=function(req,res){
 var id = req.params.idUser;
var Stringquery="SELECT * FROM usuarios where idUser=?";
                  // connection.query('SELECT * FROM customer WHERE id = ?',[id],function(err,row
                  BD.runQuery(Stringquery,id,function(error,data){
                 // console.log(data);
                  res.render("usuarios/EditarUsuario",{ 
                        title : "Formulario", 
                        info : data
                    });
                  
                  });
}

exports.guardareditado = function(req,res){
    
    var input = JSON.parse(JSON.stringify(req.body));
    var id = req.params.id;
    
    var data = {
            
            idUser    : input.idUser,
            nombre : input.nombre,
            edad  : input.edad,
            escolaridad: input.escolaridad,
            email: input.email,
            tipoCuenta: input.tipoCuenta,
            password: input.password,
            idRegistro: input.idRegistro

           
        
        };
        
        BD.runQuery("UPDATE usuarios set ? WHERE idUser = ? ",[data,id], function(err, rows)
        {
  
    
          
        });
    
    
};


